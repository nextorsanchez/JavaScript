var estudiantes=[
    {'codigo':'001', 'nombre':'Juan Perez', 'nota':16},
    {'codigo':'002', 'nombre':'Carlos Dioses', 'nota':12},
    {'codigo':'003', 'nombre':'Diana Rojas', 'nota':18},
    {'codigo':'004', 'nombre':'Miguel Sanchez', 'nota':13},
    {'codigo':'005', 'nombre':'Jose Durand', 'nota':15},
    {'codigo':'006', 'nombre':'Daniel Mendoza', 'nota':16},
    {'codigo':'007', 'nombre':'Edwin Alvarez', 'nota':14},
    {'codigo':'008', 'nombre':'Santos Collazos', 'nota':19},
    {'codigo':'009', 'nombre':'Nilton Ayala', 'nota':12},
    {'codigo':'010', 'nombre':'Juan Sojo', 'nota':10}
];

function leerJSON(json){
    var datos=  '<tr>'+
                    '<th>'+"Codigo"+'</th>'+
                    '<th>'+"Nombre"+'</th>'+
                    '<th>'+"Nota"+'</th>'+
                '</tr>';
    for(var i=0; i< json.length; i++){
        datos+='<tr>'+
                    '<td>'+json[i].codigo+'</td>'+
                    '<td>'+json[i].nombre+'</td>'+
                    '<td>'+json[i].nota+'</td>'+
                '</tr>';
    }
    document.getElementById("estudent").innerHTML = datos;
}

function promedio(json){
    var p = 0;
    var datos=  '';
    for(var i=0; i< json.length; i++){
        p+=json[i].nota;
    }
    document.getElementById("promedio").innerHTML = "Nota Promedio es:"+ p / 10;
}

function nMayor(json){
    var nMayor = json[0].nota;
    var a = '';
    for(var i=0; i< json.length; i++){
        if(json[i].nota> nMayor){
            nMayor = json[i].nota;
        }
    }
    document.getElementById("notamayor").innerHTML = "La Nota Mayor es:"+ nMayor;
}

function nMenor(json){
    var nMenor = json[0].nota;
    for(var i=0; i < json.length; i++){
        if(json[i].nota < nMenor){
            nMenor = json[i].nota;
        }
    }
    document.getElementById("notamenor").innerHTML = "La Nota Menor es:"+ nMenor;
}
function mostrarPersonas() {
    leerJSON(estudiantes);
}
function notaPromedio() {
    promedio(estudiantes);
}
function notaMayor() {
    nMayor(estudiantes);
}
function notaMenor() {
    nMenor(estudiantes);
}




